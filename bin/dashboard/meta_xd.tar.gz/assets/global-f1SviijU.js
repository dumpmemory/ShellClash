import{T as a}from"./vendor-CPwamtYr.js";import{ad as m}from"./index-Djp04eoT.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
