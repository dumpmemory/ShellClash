import{Y as a,b6 as m}from"./index-CJjWLc9u.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
