import{W as a,aZ as m}from"./index-vrXWFbcJ.js";const s=o=>a(o).locale(m.locale()).fromNow();export{s as f};
